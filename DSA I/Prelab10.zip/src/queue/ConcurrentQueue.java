package queue;

import java.util.LinkedList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * A Linked-List based Queue Is concurrent (i.e., can modify front and back in
 * parallel)
 *
 * @param <T>
 */
public class ConcurrentQueue<T> implements IQueue<T> {

	protected LinkedList<T> q;
	private Lock queueLock;
	private Condition emptyCond;
	protected T x;

	public ConcurrentQueue() {
		// TODO: Write this method

		q = new LinkedList();
		queueLock = new ReentrantLock();
		emptyCond = queueLock.newCondition();

	}

	/**
	 * Constructor: Initialize the inner list
	 */

	/**
	 * Return the size by invoking the size of the list
	 */
	public int size() {
		// TODO: Write this method
		return q.size();
	}

	/**
	 * Simply add the data to the tail of the linked list
	 */
	public void enqueue(T data) {
		queueLock.lock();
		try {
			q.add(data);

			emptyCond.signalAll();
		} finally {
			queueLock.unlock();
		}

	}

	/**
	 * Simply remove data from the head of the list, throw exception if list is
	 * empty.
	 */
	public T dequeue() {
		// TODO: Write this method

		T ret = null;
		queueLock.lock();
		// System.out.println("dequeue_locked");
		try {
			// System.out.println("try.");
			while (q.size() == 0) {

				emptyCond.await();
			}

			ret = q.removeFirst();

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			// System.out.println("finally_unlock");
			emptyCond.signalAll();
			queueLock.unlock();
			// System.out.println("Here.");

		}

		return ret;
	}
	// System.out.println("dequeue_done.");

	/*
	 * T ret = null; queueLock.lock(); try { while (size == 0) { emptyCond.await();
	 * 
	 * } ret = (T) head.data; if (tail.equals(head)) { tail = null; } head =
	 * head.next; size--; } catch (InterruptedException e) { // TODO Auto-generated
	 * catch block e.printStackTrace(); } finally {
	 * 
	 * queueLock.unlock(); } return ret;
	 */

}
