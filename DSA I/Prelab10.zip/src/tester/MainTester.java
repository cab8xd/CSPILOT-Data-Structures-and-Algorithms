package tester;

public class MainTester {

	final static int NUM_TRIALS = 100;

	public static void main(String[] args) {

		// ORIGINAL TEST
//
//		System.out.println("RUNNING SEQUENTIAL TEST");
//		System.out.println("------------------------------------");
//		long t1 = System.currentTimeMillis();
//		SequentialTester.runSequentialTest();
//		long time = System.currentTimeMillis() - t1;
//		System.out.println("------------------------------------");
//		System.out.println("SEQUENTIAL TEST COMPLETE");
//		System.out.println("TIME TO COMPLETE SEQUENTIAL TEST: " + time + " ms");
//
//		System.out.println("\n\n");
//
//		System.out.println("RUNNING CONCURRENT TEST");
//		System.out.println("------------------------------------");
//
//		ConcurrentTester ct1 = new ConcurrentTester();
//		ct1.add = true;
//		ct1.remove = false;
//		ct1.threadNumber = 1;
//		Thread th1 = new Thread(ct1);
//
//		ConcurrentTester ct2 = new ConcurrentTester();
//		ct2.add = false;
//		ct2.remove = true;
//		ct2.threadNumber = 2;
//		Thread th2 = new Thread(ct2);
//
//		th1.start();
//		th2.start();
//		try {
//			th1.join();
//			th2.join();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		System.out.println("------------------------------------");
//		System.out.println("CONCURRENT TEST COMPLETE");
//		System.out.println("TIME TO COMPLETE CONCURRENT TEST: " + Math.max(ct1.time, ct2.time) + " ms");

		// for (int test = 0; test < 10; test++) {

		System.out.println("	RUNNING SEQUENTIAL TESTS");
		System.out.println("	RUNTIME:");
		System.out.println("------------------------------------");

		long t1 = System.currentTimeMillis();
		SequentialTester.runSequentialTest();
		long time = System.currentTimeMillis() - t1;
		System.out.println(time + " ms");

		System.out.println();

		System.out.println("------------------------------------");
		System.out.println("	SEQUENTIAL TEST COMPLETE");

		// System.out.println("\n\n");

		System.out.println("	RUNNING CONCURRENT TEST");
		System.out.println("------------------------------------");

		// -------------------

		ConcurrentTester ct1 = new ConcurrentTester();
		ct1.add = true;
		ct1.remove = false;
		ct1.threadNumber = 1;
		Thread th1 = new Thread(ct1);

		ConcurrentTester ct2 = new ConcurrentTester();
		ct2.add = false;
		ct2.remove = true;
		ct2.threadNumber = 2;
		Thread th2 = new Thread(ct2);

		// -------------------

		ConcurrentTester ct3 = new ConcurrentTester();
		ct3.add = true;
		ct3.remove = false;
		ct3.threadNumber = 3;
		Thread th3 = new Thread(ct3);

		ConcurrentTester ct4 = new ConcurrentTester();
		ct4.add = false;
		ct4.remove = true;
		ct4.threadNumber = 4;
		Thread th4 = new Thread(ct4);

		ConcurrentTester ct5 = new ConcurrentTester();
		ct5.add = true;
		ct5.remove = false;
		ct5.threadNumber = 5;
		Thread th5 = new Thread(ct5);

		// -------------------

		ConcurrentTester ct6 = new ConcurrentTester();
		ct6.add = true;
		ct6.remove = false;
		ct6.threadNumber = 6;
		Thread th6 = new Thread(ct6);

		ConcurrentTester ct7 = new ConcurrentTester();
		ct7.add = false;
		ct7.remove = true;
		ct7.threadNumber = 7;
		Thread th7 = new Thread(ct7);

		ConcurrentTester ct8 = new ConcurrentTester();
		ct8.add = true;
		ct8.remove = false;
		ct8.threadNumber = 8;
		Thread th8 = new Thread(ct8);

		ConcurrentTester ct9 = new ConcurrentTester();
		ct9.add = false;
		ct9.remove = true;
		ct9.threadNumber = 9;
		Thread th9 = new Thread(ct9);

		// ------------------

		System.out.println("THREADS = 2");
		System.out.println("RUNTIME:");
		System.out.println("------------------------------------");

		th1.start();
		th2.start();
		try {
			th1.join();
			th2.join();
		} catch (Exception e) {
			e.printStackTrace();

		}
		System.out.println(Math.max(ct1.time, ct2.time) + " ms");

		System.out.println("------------------------------------");

		System.out.println("\n\n");

		System.out.println("	THREADS = 3");
		System.out.println("	RUNTIME:");
		System.out.println("------------------------------------");
		th3.start();
		th4.start();
		th5.start();
		try {
			th3.join();
			th4.join();
			th5.join();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(Math.max(Math.max(ct3.time, ct4.time), ct5.time) + " ms");

		System.out.println("------------------------------------");

		System.out.println("\n\n");

		System.out.println("	THREADS = 4");
		System.out.println("	RUNTIME:");
		System.out.println("------------------------------------");

		th6.start();
		th7.start();
		th8.start();
		th9.start();
		try {
			th6.join();
			th7.join();
			th8.join();
			th9.join();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(Math.max(Math.max(ct6.time, ct7.time), Math.max(ct8.time, ct9.time)) + " ms");
		System.out.println("------------------------------------");

		System.out.println("DONE :D"); // }

	}

}
