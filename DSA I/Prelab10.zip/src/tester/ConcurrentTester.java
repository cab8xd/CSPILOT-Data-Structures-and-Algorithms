package tester;

import queue.ConcurrentQueue;

public class ConcurrentTester implements Runnable {

	public static ConcurrentQueue<Integer> q = new ConcurrentQueue<Integer>();
	public static int NUM_TESTS = 1000000;

	/* Counter of what integer to add to the queue next */
	public static int toAdd = 1;

	/* last removed int. Used to make sure we are removing things in order */
	public static int lastRemoved = -1;

	/* Booleans determining whether this particular thread adds, removes, or both */
	public boolean add = false;
	public boolean remove = false;

	/* Thread number */
	public int threadNumber = -1;

	/* Time it took this thread to complete */
	public long time = -1;

	// ,make small and print state of queue
	// look for d>inserts
	@Override
	public void run() {
		long t1 = System.currentTimeMillis();

		/* Add a bunch of things */
		if (add) {
			for (int i = 0; i < NUM_TESTS; i++) {
				q.enqueue(toAdd);
				toAdd++;
			}

		}
		System.out.println();

		if (remove) {

			for (int i = 0; i < NUM_TESTS; i++) {
				int rem = q.dequeue();
			}
			;
		}

		this.time = System.currentTimeMillis() - t1;

	}

}
